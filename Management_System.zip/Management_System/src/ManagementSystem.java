import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;


public class ManagementSystem extends javax.swing.JFrame {


    private static final String username = "root";
    private static final String password = "secret";
    private static final String dataConn = "jdbc:mysql://localhost:3306/connector";
    
    Connection sqlConn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    int q, i, id, deleteItem;
    
    public ManagementSystem() {
        initComponents();
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Home = new javax.swing.JPanel();
        Menu = new javax.swing.JPanel();
        jbtn_Add = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jbtn_Exit = new javax.swing.JButton();
        jbtn_Delete = new javax.swing.JButton();
        jbtn_Update = new javax.swing.JButton();
        jbtn_View = new javax.swing.JButton();
        AddEmployee = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jtxt_FirstName = new javax.swing.JTextField();
        jtxt_Id = new javax.swing.JTextField();
        jtxt_Age = new javax.swing.JTextField();
        jtxt_Surname = new javax.swing.JTextField();
        jtxt_Position = new javax.swing.JTextField();
        jtxt_Gender = new javax.swing.JTextField();
        jbtn_Reset = new javax.swing.JButton();
        jbtn_AddData = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        UpdateEmployee = new javax.swing.JPanel();
        jtxt_searchId = new javax.swing.JTextField();
        jbtn_UpdateData = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jbtn_SearchId = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jtxt_EditLastName = new javax.swing.JTextField();
        jtxt_EditPosition = new javax.swing.JTextField();
        jtxt_EditFirstName = new javax.swing.JTextField();
        jtxt_EditID = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jtxt_EditAge = new javax.swing.JTextField();
        jtxt_EditGender = new javax.swing.JTextField();
        jbtn_Reset1 = new javax.swing.JButton();
        DeleteEmployee = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jtxt_searchIdToDelete = new javax.swing.JTextField();
        jbtn_SearchIdToDelete = new javax.swing.JButton();
        jbtn_DeleteData = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel_position = new javax.swing.JLabel();
        jLabel_id = new javax.swing.JLabel();
        jLabel_firstname = new javax.swing.JLabel();
        jLabel_lastname = new javax.swing.JLabel();
        jLabel_age = new javax.swing.JLabel();
        jLabel_gender = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Employees = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Management System");
        setIconImages(null);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Home.setBackground(new java.awt.Color(51, 51, 51));
        Home.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu.setBackground(new java.awt.Color(51, 51, 51));

        jbtn_Add.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_Add.setFont(new java.awt.Font("Segoe UI", 1, 8)); // NOI18N
        jbtn_Add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/add.png"))); // NOI18N
        jbtn_Add.setFocusable(false);
        jbtn_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_AddActionPerformed(evt);
            }
        });

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/team.png"))); // NOI18N

        jbtn_Exit.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_Exit.setFont(new java.awt.Font("Segoe UI", 1, 8)); // NOI18N
        jbtn_Exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logout-black.png"))); // NOI18N
        jbtn_Exit.setFocusable(false);
        jbtn_Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_ExitActionPerformed(evt);
            }
        });

        jbtn_Delete.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_Delete.setFont(new java.awt.Font("Segoe UI", 1, 8)); // NOI18N
        jbtn_Delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete.png"))); // NOI18N
        jbtn_Delete.setFocusable(false);
        jbtn_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_DeleteActionPerformed(evt);
            }
        });

        jbtn_Update.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_Update.setFont(new java.awt.Font("Segoe UI", 1, 8)); // NOI18N
        jbtn_Update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update-black.png"))); // NOI18N
        jbtn_Update.setFocusable(false);
        jbtn_Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_UpdateActionPerformed(evt);
            }
        });

        jbtn_View.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_View.setFont(new java.awt.Font("Segoe UI", 1, 8)); // NOI18N
        jbtn_View.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/list.png"))); // NOI18N
        jbtn_View.setFocusable(false);
        jbtn_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_ViewActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MenuLayout = new javax.swing.GroupLayout(Menu);
        Menu.setLayout(MenuLayout);
        MenuLayout.setHorizontalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, MenuLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(MenuLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jbtn_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbtn_Update, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbtn_Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbtn_View, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jbtn_Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );
        MenuLayout.setVerticalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MenuLayout.createSequentialGroup()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jbtn_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jbtn_Update, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jbtn_Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jbtn_View, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jbtn_Exit, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 30, Short.MAX_VALUE))
        );

        Home.add(Menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        AddEmployee.setBackground(new java.awt.Color(204, 204, 255));
        AddEmployee.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 3));
        AddEmployee.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setText("First Name");
        AddEmployee.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, -1, -1));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Employee Id ");
        AddEmployee.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, -1, -1));

        jLabel12.setText("Surname");
        AddEmployee.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, -1, -1));

        jLabel13.setText("Age");
        AddEmployee.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, -1, -1));

        jLabel14.setText("Gender");
        AddEmployee.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, -1, -1));

        jLabel15.setText("Position");
        AddEmployee.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, -1, -1));
        AddEmployee.add(jtxt_FirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, 200, -1));
        AddEmployee.add(jtxt_Id, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 200, -1));
        AddEmployee.add(jtxt_Age, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 200, -1));
        AddEmployee.add(jtxt_Surname, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, 200, -1));
        AddEmployee.add(jtxt_Position, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, 200, -1));
        AddEmployee.add(jtxt_Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, 200, -1));

        jbtn_Reset.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_Reset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbtn_Reset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/undo.png"))); // NOI18N
        jbtn_Reset.setText("Reset");
        jbtn_Reset.setFocusable(false);
        jbtn_Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_ResetActionPerformed(evt);
            }
        });
        AddEmployee.add(jbtn_Reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 280, 110, 40));

        jbtn_AddData.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_AddData.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbtn_AddData.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/add.png"))); // NOI18N
        jbtn_AddData.setText("Add Data");
        jbtn_AddData.setFocusable(false);
        jbtn_AddData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_AddDataActionPerformed(evt);
            }
        });
        AddEmployee.add(jbtn_AddData, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 130, 40));

        jLabel16.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel16.setText("Add employee");
        AddEmployee.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        Home.add(AddEmployee, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 620, 400));

        UpdateEmployee.setBackground(new java.awt.Color(204, 204, 255));
        UpdateEmployee.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 204), new java.awt.Color(204, 204, 204)));
        UpdateEmployee.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        UpdateEmployee.add(jtxt_searchId, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 140, 30));

        jbtn_UpdateData.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_UpdateData.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbtn_UpdateData.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update-black.png"))); // NOI18N
        jbtn_UpdateData.setText("Update Data");
        jbtn_UpdateData.setFocusable(false);
        jbtn_UpdateData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_UpdateDataActionPerformed(evt);
            }
        });
        UpdateEmployee.add(jbtn_UpdateData, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 310, 140, 40));

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel2.setText("Update employee");
        UpdateEmployee.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jbtn_SearchId.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_SearchId.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbtn_SearchId.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/magnifying-glass.png"))); // NOI18N
        jbtn_SearchId.setText("Search id");
        jbtn_SearchId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_SearchIdActionPerformed(evt);
            }
        });
        UpdateEmployee.add(jbtn_SearchId, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 130, 30));

        jLabel1.setText("Position");
        UpdateEmployee.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 220, -1, -1));

        jLabel3.setText("ID");
        UpdateEmployee.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, -1, -1));

        jLabel4.setText("First name");
        UpdateEmployee.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, -1, -1));

        jLabel5.setText("Last name");
        UpdateEmployee.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 220, -1, -1));

        jLabel8.setText("Age");
        UpdateEmployee.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 140, -1, -1));
        UpdateEmployee.add(jtxt_EditLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 150, -1));
        UpdateEmployee.add(jtxt_EditPosition, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 240, 150, -1));
        UpdateEmployee.add(jtxt_EditFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 150, -1));
        UpdateEmployee.add(jtxt_EditID, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 150, -1));

        jLabel19.setText("Gender");
        UpdateEmployee.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, -1, -1));
        UpdateEmployee.add(jtxt_EditAge, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 160, 150, -1));
        UpdateEmployee.add(jtxt_EditGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, 150, -1));

        jbtn_Reset1.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_Reset1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbtn_Reset1.setForeground(new java.awt.Color(204, 0, 0));
        jbtn_Reset1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/undo.png"))); // NOI18N
        jbtn_Reset1.setText("Reset");
        jbtn_Reset1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_Reset1ActionPerformed(evt);
            }
        });
        UpdateEmployee.add(jbtn_Reset1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 310, 110, 40));

        UpdateEmployee.setVisible(false);

        Home.add(UpdateEmployee, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 620, 400));

        DeleteEmployee.setBackground(new java.awt.Color(204, 204, 255));
        DeleteEmployee.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        DeleteEmployee.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 51, 0));
        jLabel18.setText("Delete employee");
        DeleteEmployee.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));
        DeleteEmployee.add(jtxt_searchIdToDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 140, 30));

        jbtn_SearchIdToDelete.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_SearchIdToDelete.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbtn_SearchIdToDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/magnifying-glass.png"))); // NOI18N
        jbtn_SearchIdToDelete.setText("Search id");
        jbtn_SearchIdToDelete.setMaximumSize(new java.awt.Dimension(110, 31));
        jbtn_SearchIdToDelete.setMinimumSize(new java.awt.Dimension(110, 31));
        jbtn_SearchIdToDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_SearchIdToDeleteActionPerformed(evt);
            }
        });
        DeleteEmployee.add(jbtn_SearchIdToDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 140, 30));

        jbtn_DeleteData.setBackground(new java.awt.Color(204, 255, 204));
        jbtn_DeleteData.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jbtn_DeleteData.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete.png"))); // NOI18N
        jbtn_DeleteData.setText("Delete Data");
        jbtn_DeleteData.setFocusable(false);
        jbtn_DeleteData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_DeleteDataActionPerformed(evt);
            }
        });
        DeleteEmployee.add(jbtn_DeleteData, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 320, 140, 40));

        jLabel6.setText("Information");
        DeleteEmployee.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel_position.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel_position, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 450, -1));

        jLabel_id.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 450, -1));

        jLabel_firstname.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel_firstname, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 450, -1));

        jLabel_lastname.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel_lastname, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 450, -1));

        jLabel_age.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel_age, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 450, -1));

        jLabel_gender.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel_gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 450, -1));

        DeleteEmployee.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 470, 140));

        jButton1.setBackground(new java.awt.Color(204, 255, 204));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/undo.png"))); // NOI18N
        jButton1.setText("Reset");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        DeleteEmployee.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 320, 110, 40));

        DeleteEmployee.setVisible(false);

        Home.add(DeleteEmployee, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 620, 400));

        Employees.setBackground(new java.awt.Color(204, 204, 255));
        Employees.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        Employees.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel17.setText("Employees");
        Employees.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        jTable4.setBackground(new java.awt.Color(204, 204, 255));
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "First name", "Surname", "Age", "Gender", "Position"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable4.setOpaque(false);
        jTable4.getTableHeader().setReorderingAllowed(false);
        jScrollPane4.setViewportView(jTable4);
        if (jTable4.getColumnModel().getColumnCount() > 0) {
            jTable4.getColumnModel().getColumn(0).setResizable(false);
            jTable4.getColumnModel().getColumn(1).setResizable(false);
            jTable4.getColumnModel().getColumn(2).setResizable(false);
            jTable4.getColumnModel().getColumn(3).setResizable(false);
            jTable4.getColumnModel().getColumn(4).setResizable(false);
            jTable4.getColumnModel().getColumn(5).setResizable(false);
        }

        Employees.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 600, 340));

        Employees.setVisible(false);

        Home.add(Employees, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 620, 400));

        getContentPane().add(Home, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 400));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtn_ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_ResetActionPerformed
        jtxt_Id.setText("");
        jtxt_FirstName.setText("");
        jtxt_Surname.setText("");
        jtxt_Age.setText("");
        jtxt_Gender.setText("");
        jtxt_Position.setText("");
    }//GEN-LAST:event_jbtn_ResetActionPerformed

    private void jbtn_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_AddActionPerformed
        AddEmployee.setVisible(true);
        UpdateEmployee.setVisible(false);
        DeleteEmployee.setVisible(false);
        Employees.setVisible(false);
    }//GEN-LAST:event_jbtn_AddActionPerformed

    private void jbtn_UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_UpdateActionPerformed
        AddEmployee.setVisible(false);
        UpdateEmployee.setVisible(true);
        DeleteEmployee.setVisible(false);
        Employees.setVisible(false);
    }//GEN-LAST:event_jbtn_UpdateActionPerformed

    private void jbtn_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_DeleteActionPerformed
        AddEmployee.setVisible(false);
        UpdateEmployee.setVisible(false);
        DeleteEmployee.setVisible(true);
        Employees.setVisible(false);
    }//GEN-LAST:event_jbtn_DeleteActionPerformed

    private void jbtn_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_ViewActionPerformed
        AddEmployee.setVisible(false);
        UpdateEmployee.setVisible(false);
        DeleteEmployee.setVisible(false);
        Employees.setVisible(true);
        
                try{
            Class.forName("com.mysql.jdbc.Driver");
            sqlConn = DriverManager.getConnection(dataConn, username, password);
            pst = sqlConn.prepareStatement("select * from connector");
            rs = pst.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)jTable4.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for (i = 1; i <=q; i++){
                    columnData.add(rs.getString("EmployeeID"));
                    columnData.add(rs.getString("FirstName"));
                    columnData.add(rs.getString("LastName"));
                    columnData.add(rs.getString("Age"));
                    columnData.add(rs.getString("Gender"));
                    columnData.add(rs.getString("Position"));
                }
                RecordTable.addRow(columnData);
            }         
        }catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex);
        }
        
    }//GEN-LAST:event_jbtn_ViewActionPerformed

    private JFrame frame;
    private void jbtn_ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_ExitActionPerformed
        frame = new JFrame("Exit");
        if(JOptionPane.showConfirmDialog(frame, "Are you sure you want to exit?", "Management System", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){
        System.exit(0);
        }
    }//GEN-LAST:event_jbtn_ExitActionPerformed

    private void jbtn_AddDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_AddDataActionPerformed
        try{
            Class.forName("com.mysql.jdbc.Driver");
            sqlConn = DriverManager.getConnection(dataConn, username, password);
            pst = sqlConn.prepareStatement("insert into connector(EmployeeID,FirstName,LastName,Age,Gender,Position)value(?,?,?,?,?,?)");
            
            if("".equals(jtxt_Id.getText()) || "".equals(jtxt_FirstName.getText()) || "".equals(jtxt_Age.getText())|| "".equals(jtxt_Gender.getText()) || "".equals(jtxt_Position.getText())){
                JOptionPane.showMessageDialog(this, "invalid Empty data");
            }else{
                pst.setString(1, jtxt_Id.getText());
                pst.setString(2, jtxt_FirstName.getText());
                pst.setString(3, jtxt_Surname.getText());
                pst.setString(4, jtxt_Age.getText());
                pst.setString(5, jtxt_Gender.getText());
                pst.setString(6, jtxt_Position.getText());
            
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data Added");
                
                jtxt_Id.setText("");
                jtxt_FirstName.setText("");
                jtxt_Surname.setText("");
                jtxt_Age.setText("");
                jtxt_Gender.setText("");
                jtxt_Position.setText("");
            }
        }catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jbtn_AddDataActionPerformed

    private void jbtn_UpdateDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_UpdateDataActionPerformed
        try{
            
            String value1 = jtxt_EditID.getText();
            String value2 = jtxt_EditFirstName.getText();
            String value3 = jtxt_EditLastName.getText();
            String value4 = jtxt_EditAge.getText();
            String value5 = jtxt_EditGender.getText();
            String value6 = jtxt_EditPosition.getText();
            
            
                Class.forName("com.mysql.jdbc.Driver");
                sqlConn = DriverManager.getConnection(dataConn, username, password);
                pst = sqlConn.prepareStatement("update connector set EmployeeID='"+value1+"' ,FirstName='"+value2+"',LastName='"+value3+"',Age='"+value4+"',Gender='"+value5+"',Position='"+value6+"' where EmployeeID='"+value1+"'");
                
                
                if("".equals(value1) || "".equals(value2) || "".equals(value3)|| "".equals(value4) || "".equals(value5)|| "".equals(value6)){
                    JOptionPane.showMessageDialog(this, "invalid Empty data");
                }else{
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Data Updated"); 
                    jtxt_EditID.setText("");
                    jtxt_EditFirstName.setText("");
                    jtxt_EditLastName.setText("");
                    jtxt_EditAge.setText("");
                    jtxt_EditGender.setText("");
                    jtxt_EditPosition.setText("");
                    jtxt_searchId.setText(""); 
                }

        }catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jbtn_UpdateDataActionPerformed

    private void jbtn_SearchIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_SearchIdActionPerformed
        try{
            Class.forName("com.mysql.jdbc.Driver");
            sqlConn = DriverManager.getConnection(dataConn, username, password);
            pst = sqlConn.prepareStatement("select EmployeeID,FirstName,LastName,Age,Gender,Position from connector where EmployeeID=?");
            String EmployeeID = jtxt_searchId.getText(); 
            pst.setString(1, EmployeeID);
            ResultSet rs1 = pst.executeQuery();
                        
            if(rs1.next()==false){
                JOptionPane.showMessageDialog(this, "Record Not Found");
                jtxt_EditID.setText("");
                jtxt_EditFirstName.setText("");
                jtxt_EditLastName.setText("");
                jtxt_EditAge.setText("");
                jtxt_EditGender.setText("");
                jtxt_EditPosition.setText("");
                jtxt_searchId.setText("");
            }else{
                
                    jtxt_EditID.setText(rs1.getString("EmployeeID"));
                    jtxt_EditFirstName.setText(rs1.getString("FirstName"));
                    jtxt_EditLastName.setText(rs1.getString("LastName"));
                    jtxt_EditAge.setText(rs1.getString("Age"));
                    jtxt_EditGender.setText(rs1.getString("Gender"));
                    jtxt_EditPosition.setText(rs1.getString("Position"));
            }
            
        }catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jbtn_SearchIdActionPerformed

    private void jbtn_DeleteDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_DeleteDataActionPerformed

        try{
            Class.forName("com.mysql.jdbc.Driver");
            sqlConn = DriverManager.getConnection(dataConn, username, password);
            pst = sqlConn.prepareStatement("delete from connector where EmployeeID=?");
            pst.setString(1, jtxt_searchIdToDelete.getText());
            
            
            if("".equals(jtxt_searchIdToDelete.getText())){
                JOptionPane.showMessageDialog(this, "invalid Empty data");
            }else{
            
                pst.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data Deleted"); 
                jLabel_id.setText("");
                jLabel_firstname.setText("");
                jLabel_lastname.setText("");
                jLabel_age.setText("");
                jLabel_gender.setText("");
                jLabel_position.setText("");
                jtxt_searchIdToDelete.setText("");
            }
                                    
        }catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jbtn_DeleteDataActionPerformed

    private void jbtn_SearchIdToDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_SearchIdToDeleteActionPerformed
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            sqlConn = DriverManager.getConnection(dataConn, username, password);
            pst = sqlConn.prepareStatement("select EmployeeID,FirstName,LastName,Age,Gender,Position from connector where EmployeeID=?");
            String EmployeeID = jtxt_searchIdToDelete.getText(); 
            pst.setString(1, EmployeeID);
            ResultSet rs1 = pst.executeQuery();
                        
            if(rs1.next()==false){
                JOptionPane.showMessageDialog(this, "Record Not Found");
                    jLabel_id.setText("");
                    jLabel_firstname.setText("");
                    jLabel_lastname.setText("");
                    jLabel_age.setText("");
                    jLabel_gender.setText("");
                    jLabel_position.setText("");
                    jtxt_searchIdToDelete.setText("");
            }else{
                
                    String val1 = rs1.getString("EmployeeID");
                    String val2 = rs1.getString("FirstName");
                    String val3 = rs1.getString("LastName");
                    String val4 = rs1.getString("Age");
                    String val5 = rs1.getString("Gender");
                    String val6 = rs1.getString("Position");
                    
                    jLabel_id.setText("ID: "+ val1);
                    jLabel_firstname.setText("First Name: "+ val2);
                    jLabel_lastname.setText("Last name: "+ val3);
                    jLabel_age.setText("Age: "+ val4);
                    jLabel_gender.setText("Gender: "+ val5);
                    jLabel_position.setText("Position: "+ val6);
                    }
            
        }catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ManagementSystem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jbtn_SearchIdToDeleteActionPerformed

    private void jbtn_Reset1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_Reset1ActionPerformed

                jtxt_EditID.setText("");
                jtxt_EditFirstName.setText("");
                jtxt_EditLastName.setText("");
                jtxt_EditAge.setText("");
                jtxt_EditGender.setText("");
                jtxt_EditPosition.setText("");
                jtxt_searchId.setText("");
    }//GEN-LAST:event_jbtn_Reset1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
            jLabel_id.setText("");
            jLabel_firstname.setText("");
            jLabel_lastname.setText("");
            jLabel_age.setText("");
            jLabel_gender.setText("");
            jLabel_position.setText("");
            jtxt_searchIdToDelete.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManagementSystem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AddEmployee;
    private javax.swing.JPanel DeleteEmployee;
    private javax.swing.JPanel Employees;
    private javax.swing.JPanel Home;
    private javax.swing.JPanel Menu;
    private javax.swing.JPanel UpdateEmployee;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_age;
    private javax.swing.JLabel jLabel_firstname;
    private javax.swing.JLabel jLabel_gender;
    private javax.swing.JLabel jLabel_id;
    private javax.swing.JLabel jLabel_lastname;
    private javax.swing.JLabel jLabel_position;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable4;
    private javax.swing.JButton jbtn_Add;
    private javax.swing.JButton jbtn_AddData;
    private javax.swing.JButton jbtn_Delete;
    private javax.swing.JButton jbtn_DeleteData;
    private javax.swing.JButton jbtn_Exit;
    private javax.swing.JButton jbtn_Reset;
    private javax.swing.JButton jbtn_Reset1;
    private javax.swing.JButton jbtn_SearchId;
    private javax.swing.JButton jbtn_SearchIdToDelete;
    private javax.swing.JButton jbtn_Update;
    private javax.swing.JButton jbtn_UpdateData;
    private javax.swing.JButton jbtn_View;
    private javax.swing.JTextField jtxt_Age;
    private javax.swing.JTextField jtxt_EditAge;
    private javax.swing.JTextField jtxt_EditFirstName;
    private javax.swing.JTextField jtxt_EditGender;
    private javax.swing.JTextField jtxt_EditID;
    private javax.swing.JTextField jtxt_EditLastName;
    private javax.swing.JTextField jtxt_EditPosition;
    private javax.swing.JTextField jtxt_FirstName;
    private javax.swing.JTextField jtxt_Gender;
    private javax.swing.JTextField jtxt_Id;
    private javax.swing.JTextField jtxt_Position;
    private javax.swing.JTextField jtxt_Surname;
    private javax.swing.JTextField jtxt_searchId;
    private javax.swing.JTextField jtxt_searchIdToDelete;
    // End of variables declaration//GEN-END:variables
}
